function aleart(s){
	window.aleart(s);
}